def formulaAux(x):
    digitos = {}
    for num in x:
        for d in str(num):
            digitos[d] = digitos.get(d, 0) + 1
            if digitos[d] > R:
                return False
    return True

def formula(C):
    lista = []
    for A in range(9999, 99999, 1):
        B = A // C
        if B >= 1000 and B and A % B == 0 and A // B == C:
            if formulaAux((A, B)):
                lista.append((A, B))
                print(f"{A}/{B} = {C}")
                print()
    return lista

T = int(input())
while T:
    T-=1
    C,R= input().split()
    C= int(C)
    R= int(R)
    formula(C)